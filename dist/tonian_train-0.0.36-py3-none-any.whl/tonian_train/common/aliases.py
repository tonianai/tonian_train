
from typing import Callable
import torch.nn as nn

InitializerFn = Callable
ActivationFn = nn.Module